package src.edu.rafael.Curso.primeiros_passos_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimeirosPassosSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
